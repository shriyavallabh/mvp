const express = require('express');
const router = express.Router();
const pm2Monitor = require('../services/pm2-monitor');
const metricsService = require('../services/metrics');
const backupService = require('../services/backup');
const agentMonitor = require('../services/agent-monitor');
const advisorService = require('../services/advisor-service');
const contentService = require('../services/content-service');
const logService = require('../services/log-service');

// Story 3.2 Integration Services
const WebhookConnector = require('../services/webhook-connector');
const ButtonAnalyticsService = require('../services/button-analytics');
const CRMMonitorService = require('../services/crm-monitor');

// Initialize Story 3.2 services
const webhookConnector = new WebhookConnector();
const buttonAnalytics = new ButtonAnalyticsService();
const crmMonitor = new CRMMonitorService();

router.get('/health', async (req, res) => {
  try {
    const health = await pm2Monitor.getSystemHealth();
    res.json(health);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/processes', async (req, res) => {
  try {
    const processes = await pm2Monitor.getProcessList();
    res.json(processes);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/metrics', async (req, res) => {
  try {
    const metrics = await metricsService.getMetrics();
    res.json(metrics);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/agents/status', async (req, res) => {
  try {
    const status = await agentMonitor.getAgentStatus();
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/agents/hierarchy', async (req, res) => {
  try {
    const hierarchy = await agentMonitor.getAgentHierarchy();
    res.json(hierarchy);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/agents/logs/:agentName', async (req, res) => {
  try {
    const logs = await agentMonitor.getAgentLogs(req.params.agentName);
    res.json(logs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/agents/trigger', async (req, res) => {
  try {
    const { agentName, params } = req.body;
    const result = await agentMonitor.triggerAgent(agentName, params);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/advisors', async (req, res) => {
  try {
    const advisors = await advisorService.getAdvisors();
    res.json(advisors);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/advisors', async (req, res) => {
  try {
    const advisor = await advisorService.createAdvisor(req.body);
    res.json(advisor);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.put('/advisors/:id', async (req, res) => {
  try {
    const advisor = await advisorService.updateAdvisor(req.params.id, req.body);
    res.json(advisor);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.delete('/advisors/:id', async (req, res) => {
  try {
    await advisorService.deleteAdvisor(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/content/pending', async (req, res) => {
  try {
    const content = await contentService.getPendingContent();
    res.json(content);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/content/approve/:id', async (req, res) => {
  try {
    const result = await contentService.approveContent(req.params.id);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/content/reject/:id', async (req, res) => {
  try {
    const result = await contentService.rejectContent(req.params.id, req.body.reason);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/logs', async (req, res) => {
  try {
    const { level, search, limit = 100 } = req.query;
    const logs = await logService.getLogs({ level, search, limit: parseInt(limit) });
    res.json(logs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/backup/list', async (req, res) => {
  try {
    const backups = await backupService.listBackups();
    res.json(backups);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/backup/create', async (req, res) => {
  try {
    const backup = await backupService.createBackup();
    res.json(backup);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/backup/restore/:id', async (req, res) => {
  try {
    const result = await backupService.restoreBackup(req.params.id);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/whatsapp/status', async (req, res) => {
  try {
    const status = await metricsService.getWhatsAppStatus();
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/sheets/status', async (req, res) => {
  try {
    const status = await metricsService.getSheetsStatus();
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Story 3.2 Integration API Endpoints
router.get('/webhook/status', async (req, res) => {
  try {
    const metrics = webhookConnector.getMetrics();
    res.json({
      status: metrics.status,
      uptime: metrics.uptime,
      isConnected: metrics.isConnected,
      lastHeartbeat: metrics.lastHeartbeat,
      messagesProcessed: metrics.messagesProcessed,
      reconnectAttempts: metrics.reconnectAttempts
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/webhook/metrics', async (req, res) => {
  try {
    const dashboardMetrics = await buttonAnalytics.getDashboardMetrics();
    const webhookMetrics = webhookConnector.getMetrics();
    const crmMetrics = crmMonitor.getCRMMetrics();
    
    res.json({
      timestamp: new Date().toISOString(),
      webhook_status: {
        status: webhookMetrics.status,
        uptime_percentage: webhookMetrics.uptime,
        messages_processed: webhookMetrics.messagesProcessed,
        is_connected: webhookMetrics.isConnected
      },
      button_analytics: dashboardMetrics?.button_analytics || {},
      chat_analytics: dashboardMetrics?.chat_analytics || {},
      crm_metrics: crmMetrics,
      hourly_distribution: dashboardMetrics?.hourly_distribution || {},
      total_button_clicks: dashboardMetrics?.button_analytics?.total_clicks || 0
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/webhook/button-analytics', async (req, res) => {
  try {
    const analytics = await buttonAnalytics.getTodayButtonAnalytics();
    const hourlyDistribution = await buttonAnalytics.getHourlyButtonDistribution();
    
    res.json({
      daily_totals: analytics.daily_totals,
      response_times: analytics.response_times,
      unique_users: analytics.unique_users,
      total_clicks: analytics.total_clicks,
      hourly_distribution: hourlyDistribution
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/webhook/crm-analytics', async (req, res) => {
  try {
    const crmMetrics = crmMonitor.getCRMMetrics();
    const conversationAnalytics = crmMonitor.getConversationAnalytics();
    const chatAnalytics = await buttonAnalytics.getChatAnalytics();
    
    res.json({
      real_time_metrics: crmMetrics,
      conversation_analytics: conversationAnalytics,
      database_analytics: chatAnalytics
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/webhook/health-metrics', async (req, res) => {
  try {
    const healthMetrics = await buttonAnalytics.getWebhookHealthMetrics();
    const webhookMetrics = webhookConnector.getMetrics();
    
    res.json({
      webhook_uptime: healthMetrics.uptime_percentage,
      total_checks: healthMetrics.total_checks,
      healthy_checks: healthMetrics.healthy_checks,
      avg_response_time: healthMetrics.avg_response_time,
      last_check: healthMetrics.last_check,
      current_status: webhookMetrics.status,
      error_count: webhookMetrics.errors?.length || 0,
      recent_errors: webhookMetrics.errors?.slice(-5) || []
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Test endpoint for webhook integration
router.post('/webhook/simulate-event', async (req, res) => {
  try {
    const { type, data } = req.body;
    
    if (type === 'button_click') {
      const result = await buttonAnalytics.recordButtonClick(
        data.button_type || 'UNLOCK_CONTENT',
        data.contact_id || 'test_user',
        data.contact_name || 'Test User',
        data.response_time || 1000
      );
      res.json({ success: result, message: 'Button click recorded' });
      
    } else if (type === 'chat_interaction') {
      const result = await buttonAnalytics.recordChatInteraction(
        data.contact_id || 'test_user',
        data.contact_name || 'Test User',
        'text',
        data.message || 'Test message',
        data.response || 'Test response',
        data.response_time || 2000,
        data.quality_score || 4.0
      );
      res.json({ success: result, message: 'Chat interaction recorded' });
      
    } else {
      res.status(400).json({ error: 'Invalid event type' });
    }
    
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;