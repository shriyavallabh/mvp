#!/bin/bash

echo "Setting up WhatsApp service on VM..."

# Navigate to project directory
cd /home/mvp

# Create necessary directories
mkdir -p agents/services
mkdir -p data
mkdir -p logs/whatsapp
mkdir -p config

# Copy WhatsApp service
cp /tmp/whatsapp-deploy/whatsapp-service.js agents/services/ 2>/dev/null || true
cp /tmp/whatsapp-deploy/webhook-server-permanent.js .

# Install dependencies if needed
if ! npm list axios > /dev/null 2>&1; then
    npm install axios --save
fi

if ! npm list express > /dev/null 2>&1; then
    npm install express body-parser cors --save
fi

# Create advisor data file
cat > data/advisors.json << 'EOF'
[
  {
    "arn": "ARN_001",
    "name": "Shruti Petkar",
    "phone": "9673758777",
    "whatsapp": "919673758777",
    "client_segment": "families",
    "tone": "friendly",
    "content_focus": "balanced",
    "active": true,
    "payment_status": "paid"
  },
  {
    "arn": "ARN_002",
    "name": "Shri Avalok Petkar",
    "phone": "9765071249",
    "whatsapp": "919765071249",
    "client_segment": "entrepreneurs",
    "tone": "professional",
    "content_focus": "growth",
    "active": true,
    "payment_status": "paid"
  },
  {
    "arn": "ARN_003",
    "name": "Vidyadhar Petkar",
    "phone": "8975758513",
    "whatsapp": "918975758513",
    "client_segment": "retirees",
    "tone": "educational",
    "content_focus": "safety",
    "active": true,
    "payment_status": "paid"
  }
]
EOF

# Update environment variables
if ! grep -q "WHATSAPP_TEST_MODE" /home/mvp/.env 2>/dev/null; then
    echo "" >> /home/mvp/.env
    echo "# WhatsApp Configuration" >> /home/mvp/.env
    echo "WHATSAPP_TEST_MODE=true" >> /home/mvp/.env
    echo "WEBHOOK_PORT=5001" >> /home/mvp/.env
    echo "WEBHOOK_SECRET=finadvise-secret-2024" >> /home/mvp/.env
fi

# Stop old webhook server if running
pm2 stop webhook-server 2>/dev/null || true
pm2 delete webhook-server 2>/dev/null || true

# Start new webhook server
pm2 start webhook-server-permanent.js --name whatsapp-webhook --watch false

# Save PM2 configuration
pm2 save

echo "✅ WhatsApp service setup complete!"
