const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const path = require('path');
const http = require('http');
const socketIo = require('socket.io');
const ejs = require('ejs');

const authRoutes = require('./routes/auth');
const apiRoutes = require('./routes/api');
const viewRoutes = require('./routes/views');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

const PORT = process.env.PORT || 8080;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: process.env.SESSION_SECRET || 'finadvise-dashboard-secret-key-change-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000
  }
}));

const authMiddleware = (req, res, next) => {
  if (!req.session.user && !req.path.startsWith('/auth')) {
    return res.redirect('/auth/login');
  }
  next();
};

app.use('/auth', authRoutes);

app.use(authMiddleware);

app.use('/api', apiRoutes);
app.use('/', viewRoutes);

io.on('connection', (socket) => {
  console.log('New client connected');
  
  socket.on('subscribe-agents', () => {
    socket.join('agent-updates');
  });
  
  socket.on('disconnect', () => {
    console.log('Client disconnected');
  });
});

global.io = io;

server.listen(PORT, () => {
  console.log(`Dashboard server running on port ${PORT}`);
  console.log(`Access dashboard at http://localhost:${PORT}`);
});

module.exports = { app, server, io };