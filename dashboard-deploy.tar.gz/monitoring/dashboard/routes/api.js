const express = require('express');
const router = express.Router();
const pm2Monitor = require('../services/pm2-monitor');
const metricsService = require('../services/metrics');
const backupService = require('../services/backup');
const agentMonitor = require('../services/agent-monitor');
const advisorService = require('../services/advisor-service');
const contentService = require('../services/content-service');
const logService = require('../services/log-service');

router.get('/health', async (req, res) => {
  try {
    const health = await pm2Monitor.getSystemHealth();
    res.json(health);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/processes', async (req, res) => {
  try {
    const processes = await pm2Monitor.getProcessList();
    res.json(processes);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/metrics', async (req, res) => {
  try {
    const metrics = await metricsService.getMetrics();
    res.json(metrics);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/agents/status', async (req, res) => {
  try {
    const status = await agentMonitor.getAgentStatus();
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/agents/hierarchy', async (req, res) => {
  try {
    const hierarchy = await agentMonitor.getAgentHierarchy();
    res.json(hierarchy);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/agents/logs/:agentName', async (req, res) => {
  try {
    const logs = await agentMonitor.getAgentLogs(req.params.agentName);
    res.json(logs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/agents/trigger', async (req, res) => {
  try {
    const { agentName, params } = req.body;
    const result = await agentMonitor.triggerAgent(agentName, params);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/advisors', async (req, res) => {
  try {
    const advisors = await advisorService.getAdvisors();
    res.json(advisors);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/advisors', async (req, res) => {
  try {
    const advisor = await advisorService.createAdvisor(req.body);
    res.json(advisor);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.put('/advisors/:id', async (req, res) => {
  try {
    const advisor = await advisorService.updateAdvisor(req.params.id, req.body);
    res.json(advisor);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.delete('/advisors/:id', async (req, res) => {
  try {
    await advisorService.deleteAdvisor(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/content/pending', async (req, res) => {
  try {
    const content = await contentService.getPendingContent();
    res.json(content);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/content/approve/:id', async (req, res) => {
  try {
    const result = await contentService.approveContent(req.params.id);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/content/reject/:id', async (req, res) => {
  try {
    const result = await contentService.rejectContent(req.params.id, req.body.reason);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/logs', async (req, res) => {
  try {
    const { level, search, limit = 100 } = req.query;
    const logs = await logService.getLogs({ level, search, limit: parseInt(limit) });
    res.json(logs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/backup/list', async (req, res) => {
  try {
    const backups = await backupService.listBackups();
    res.json(backups);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/backup/create', async (req, res) => {
  try {
    const backup = await backupService.createBackup();
    res.json(backup);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.post('/backup/restore/:id', async (req, res) => {
  try {
    const result = await backupService.restoreBackup(req.params.id);
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/whatsapp/status', async (req, res) => {
  try {
    const status = await metricsService.getWhatsAppStatus();
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get('/sheets/status', async (req, res) => {
  try {
    const status = await metricsService.getSheetsStatus();
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;