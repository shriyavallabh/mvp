const fs = require('fs').promises;
const path = require('path');
const axios = require('axios');
const { google } = require('googleapis');

class MetricsService {
  constructor() {
    this.metricsFile = path.join(__dirname, '../../../data/metrics.json');
    this.sheets = null;
    this.initGoogleSheets();
  }

  async initGoogleSheets() {
    try {
      const auth = new google.auth.GoogleAuth({
        keyFile: path.join(__dirname, '../../../config/credentials.json'),
        scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly']
      });
      this.sheets = google.sheets({ version: 'v4', auth });
    } catch (error) {
      console.error('Failed to initialize Google Sheets:', error);
    }
  }

  async getMetrics() {
    const today = new Date().toISOString().split('T')[0];
    
    try {
      const dailyMetrics = await this.getDailyMetrics(today);
      const weeklyMetrics = await this.getWeeklyMetrics();
      const monthlyMetrics = await this.getMonthlyMetrics();
      const advisorMetrics = await this.getAdvisorMetrics();
      
      return {
        daily: dailyMetrics,
        weekly: weeklyMetrics,
        monthly: monthlyMetrics,
        advisors: advisorMetrics,
        lastUpdated: new Date().toISOString()
      };
    } catch (error) {
      console.error('Error getting metrics:', error);
      return {
        error: error.message,
        daily: {},
        weekly: {},
        monthly: {},
        advisors: {}
      };
    }
  }

  async getDailyMetrics(date) {
    try {
      const logsPath = path.join(__dirname, '../../../logs');
      const files = await fs.readdir(logsPath);
      
      const contentGenerated = files.filter(f => 
        f.includes('content-orchestrator') && f.includes(date)
      ).length;
      
      const messagesDelivered = files.filter(f => 
        f.includes('distribution') && f.includes(date)
      ).length;
      
      return {
        date,
        contentGenerated,
        messagesDelivered,
        approvalsPending: 0,
        errorsCount: 0
      };
    } catch (error) {
      return {
        date,
        contentGenerated: 0,
        messagesDelivered: 0,
        approvalsPending: 0,
        errorsCount: 0
      };
    }
  }

  async getWeeklyMetrics() {
    const metrics = {
      totalContent: 0,
      totalDeliveries: 0,
      avgResponseTime: 0,
      successRate: 100
    };
    
    try {
      const dataFile = path.join(__dirname, '../../../data/campaigns.json');
      const exists = await fs.access(dataFile).then(() => true).catch(() => false);
      
      if (exists) {
        const data = JSON.parse(await fs.readFile(dataFile, 'utf8'));
        metrics.totalContent = data.campaigns?.length || 0;
        metrics.totalDeliveries = data.deliveries?.length || 0;
      }
    } catch (error) {
      console.error('Error reading weekly metrics:', error);
    }
    
    return metrics;
  }

  async getMonthlyMetrics() {
    return {
      totalAdvisorsServed: 0,
      totalContentPieces: 0,
      avgEngagementRate: 0,
      topPerformingContent: []
    };
  }

  async getAdvisorMetrics() {
    if (!this.sheets) {
      return { total: 0, active: 0, inactive: 0 };
    }
    
    try {
      const response = await this.sheets.spreadsheets.values.get({
        spreadsheetId: process.env.GOOGLE_SHEET_ID,
        range: 'Advisors!A:F'
      });
      
      const rows = response.data.values || [];
      const advisors = rows.slice(1);
      
      return {
        total: advisors.length,
        active: advisors.filter(row => row[3] === 'active').length,
        inactive: advisors.filter(row => row[3] === 'inactive').length,
        newThisWeek: advisors.filter(row => {
          const createdDate = new Date(row[4]);
          const weekAgo = new Date();
          weekAgo.setDate(weekAgo.getDate() - 7);
          return createdDate > weekAgo;
        }).length
      };
    } catch (error) {
      console.error('Error getting advisor metrics:', error);
      return { total: 0, active: 0, inactive: 0, newThisWeek: 0 };
    }
  }

  async getWhatsAppStatus() {
    try {
      const response = await axios.get(
        `https://graph.facebook.com/v21.0/${process.env.WHATSAPP_PHONE_NUMBER_ID}`,
        {
          headers: {
            'Authorization': `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`
          }
        }
      );
      
      return {
        status: 'connected',
        phoneNumber: response.data.display_phone_number,
        qualityRating: response.data.quality_rating || 'GREEN',
        lastChecked: new Date().toISOString()
      };
    } catch (error) {
      return {
        status: 'error',
        error: error.message,
        lastChecked: new Date().toISOString()
      };
    }
  }

  async getSheetsStatus() {
    if (!this.sheets) {
      return {
        status: 'disconnected',
        error: 'Google Sheets not configured',
        lastChecked: new Date().toISOString()
      };
    }
    
    try {
      const response = await this.sheets.spreadsheets.get({
        spreadsheetId: process.env.GOOGLE_SHEET_ID
      });
      
      return {
        status: 'connected',
        spreadsheetName: response.data.properties.title,
        sheets: response.data.sheets.map(s => s.properties.title),
        lastChecked: new Date().toISOString()
      };
    } catch (error) {
      return {
        status: 'error',
        error: error.message,
        lastChecked: new Date().toISOString()
      };
    }
  }

  async recordMetric(type, data) {
    try {
      let metrics = {};
      const exists = await fs.access(this.metricsFile).then(() => true).catch(() => false);
      
      if (exists) {
        metrics = JSON.parse(await fs.readFile(this.metricsFile, 'utf8'));
      }
      
      if (!metrics[type]) {
        metrics[type] = [];
      }
      
      metrics[type].push({
        ...data,
        timestamp: new Date().toISOString()
      });
      
      if (metrics[type].length > 1000) {
        metrics[type] = metrics[type].slice(-1000);
      }
      
      await fs.writeFile(this.metricsFile, JSON.stringify(metrics, null, 2));
    } catch (error) {
      console.error('Error recording metric:', error);
    }
  }
}

module.exports = new MetricsService();